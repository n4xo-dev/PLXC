/**
 * Variable class to represent a variable in the symbol table
 */
public class Variable {
  private String name;
  private Type type;
  private String holder; // Variable in Three-Address Code that holds the value

  /**
   * Constructor for the Variable class
   * @param name
   * @param type
   * @param holder
   */
  public Variable(String name, Type type, String holder) {
      this.name = name;
      this.type = type;
      this.holder = holder;
  }

  
  public String getName() {
      return name;
  }

  public Type getType() {
      return type;
  }

  public String getHolder() {
      return holder;
  }

  @Override
  public String toString() {
      return type + " " + name + "->" + holder;
  }
}

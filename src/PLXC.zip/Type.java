public enum Type {
  INT, FLOAT, CHAR, STRING;

  public static Type getPrevalentType(Type t1, Type t2) {
    t1.checkCompatible(t2);
    if (t1 == FLOAT || t2 == FLOAT)
      return FLOAT;
    return INT;
  }

  public static String getCharCode(String c) {
    String ch = c.substring(1, c.length() - 1);
    if (ch.length() == 1) {
      return String.valueOf((int) ch.charAt(0));
    }   
    if (ch.substring(0, 2).equals("\\u")) {
      return String.valueOf((int) Integer.parseInt(ch.substring(2), 16));
    }
    switch (ch) {
      case "\\n":
        return "10";
      case "\\t":
        return "9";
      case "\\r":
        return "13";
      case "\\b":
        return "8";
      case "\\f":
        return "12";
      case "\\\"":
        return "34";
      case "\\'":
        return "39";
      case "\\\\":
        return "92";
      default:
        throw new RuntimeException("Invalid character " + c);
    }
  }

  public void checkCompatible(Type t) {
    if (this == CHAR && t == FLOAT || this == FLOAT && t == CHAR) {
      throw new RuntimeException("Incompatible types: CHAR and FLOAT");
    }
    if (this == STRING || t == STRING) {
      throw new RuntimeException("STRING cannot be operated with");
    }
  }

  public void checkCastable(Type t) {
    switch (this) {
      case INT:
        if (t == FLOAT || t == CHAR) {
          throw new RuntimeException("Cannot cast INT to " + t);
        }
        break;
      case FLOAT:
        if (t == CHAR) {
          throw new RuntimeException("Cannot cast FLOAT to CHAR");
        }
        break;
      case CHAR:
        if (t == FLOAT) {
          throw new RuntimeException("Cannot cast CHAR to FLOAT");
        }
        break;
      default:
        throw new RuntimeException("Cannot cast " + this + " to " + t);
    }
  }

  public String getJavaType() {
    switch (this) {
      case INT:
        return "int";
      case FLOAT:
        return "float";
      case CHAR:
        return "char";
      case STRING:
        return "String";
      default:
        throw new RuntimeException("Invalid type " + this);
    }
  }

  public boolean isCastUnnecessary(Type t) {
    return this == t || this == CHAR && t == INT || this == INT && t == CHAR;
  }
}
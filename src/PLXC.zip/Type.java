public enum Type {
  INT, FLOAT, CHAR, STRING;

  public boolean check(String value) {
    // Check if the value is valid for the type
    switch (this) {
      case INT:
        try {
          Integer.parseInt(value);
        } catch (NumberFormatException e) {
          return false;
        }
        break;
      case FLOAT:
        try {
          Float.parseFloat(value);
        } catch (NumberFormatException e) {
          return false;
        }
        break;
      case CHAR:
        if (value.length() > 1) {
          return false;
        }
        break;
      case STRING:
        break;
    }
    return true;
  }

  public static Type getPrevalentType(Type t1, Type t2) {
    t1.checkCompatible(t2);
    if (t1 == FLOAT || t2 == FLOAT)
      return FLOAT;
    if (t1 == INT || t2 == INT)
      return INT;
    return CHAR;
  }

  public void checkCompatible(Type t) {
    if (this == CHAR && t == FLOAT || this == FLOAT && t == CHAR) {
      throw new RuntimeException("Incompatible types: CHAR and FLOAT");
    }
    if (this == STRING || t == STRING) {
      throw new RuntimeException("STRING cannot be operated with");
    }
  }
}